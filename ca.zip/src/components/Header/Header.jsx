import React from "react";
import "./Header.css";
import { FaPaperPlane } from "react-icons/fa";
import Particles from "react-tsparticles";

const Header = () => {
  const particlesOptions = {
    particles: {
      number: {
        value: 50, // adjust the number of particles
      },
      size: {
        value: 3, // adjust the size of particles
      },
    },
    interactivity: {
      detectsOn: "canvas",
      events: {
        onClick: {
          enable: true,
          mode: "push",
        },
        onHover: {
          enable: true,
          mode: "repulse",
        },
      },
    },
  };

  return (
    <header className="header flex flex-center flex-column">
      {/* Particle background */}
      <Particles
        id="tsparticles"
        options={particlesOptions}
        style={{ position: "absolute", width: "100%", height: "100%" }}
      />

      <div className="container">
        <div className="header-content text-center flex flex-column">
          <h1 className="header-title">Campus Ambassador</h1>
          <h3
            style={{
              fontSize: "40px",
              fontWeight: "400",
              lineHeight: "1.2",
              background: "white",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
            }}
          >
            SANKALAN'24
          </h3>
          <p className="text-lead">
            Civil Engineering Conclave-Sankalan by SoCE IIT Kanpur invites
            Campus Ambassadors. Register for this opportunity now!!
          </p>
          <a href="/glogin" className="btn header-btn btn-blue">
            <FaPaperPlane /> <span>Register Here</span>
          </a>
        </div>
      </div>
    </header>
  );
};

export default Header;
